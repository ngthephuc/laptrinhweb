
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NguyenThePhuc_241230818_OnTap.Models;

namespace NguyenThePhuc_241230818_OnTap.Controllers
{
    public class HomeController : Controller
    {
        private readonly QLTaiSanContext _context;

        public HomeController(QLTaiSanContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // Lấy danh sách loại tài sản
            ViewBag.LoaiTaiSans = await _context.LoaiTaiSans.ToListAsync();

            // Lấy tài sản có nguyên giá từ 20 triệu trở lên
            // Tài sản có NguyenGia = NULL tự động bị loại
            var dsTaiSan = await _context.TaiSans
                .Where(t => t.NguyenGia >= 20)
                .ToListAsync();

            return View(dsTaiSan);
        }
        [HttpGet]
        public async Task<IActionResult> LocTaiSan(int maLoai)
        {
            var loaiTaiSan = await _context.LoaiTaiSans
                .FirstOrDefaultAsync(x => x.MaLoai == maLoai);

            if (loaiTaiSan == null)
            {
                return NotFound();
            }

            var dsTaiSan = await _context.TaiSans
                .Where(x => x.MaLoai == maLoai && x.NguyenGia >= 20)
                .ToListAsync();

            ViewBag.TenLoai = loaiTaiSan.TenLoai;

            return PartialView("NguyenThePhuc_MainContent", dsTaiSan);
        }
    }
}
