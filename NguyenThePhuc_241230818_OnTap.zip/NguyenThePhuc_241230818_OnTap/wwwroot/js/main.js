// AssetHub - hiệu ứng giao diện cơ bản (nút "lên đầu trang")
$(function () {
    $(window).on('scroll', function () {
        $('.to-top').toggle($(this).scrollTop() > 200);
    });
    $('.to-top').on('click', function () {
        $('html, body').animate({ scrollTop: 0 }, 400);
    });
    $('.search-box input').on('focus', function () { $(this).select(); });
});


$(document).ready(function () {

    // Bấm vào loại tài sản trên menu
    $(".menu a[data-maloai]").on("click", function (e) {
        e.preventDefault();

        var maLoai = $(this).data("maloai");

        // Gửi AJAX đến HomeController
        $.ajax({
            url: "/Home/LocTaiSan",
            type: "GET",
            data: { maLoai: maLoai },

            success: function (result) {
                // Thay nội dung cũ bằng danh sách mới
                $("#vungTaiSan").replaceWith(result);

                // Đổi trạng thái menu đang chọn
                $(".menu li").removeClass("active");
                $(this).parent().addClass("active");
            },

            error: function () {
                alert("Không thể tải danh sách tài sản!");
            }
        });
    });

});

