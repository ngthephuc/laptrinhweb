
using Microsoft.AspNetCore.Mvc;
using NguyenThePhuc_241230818_DeThiMau2026.Models;
using System.Diagnostics;

namespace NguyenThePhuc_241230818_DeThiMau2026.Controllers
{
    public class HomeController : Controller
    {
        private readonly QLNhaSachContext _context;

        public HomeController(QLNhaSachContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            ViewBag.TheLoais = _context.TheLoais.ToList();

            var dsSach = _context.Saches
                .Where(s => s.Gia >= 100)
                .ToList();

            return View(dsSach);
        }

        // Lọc sách theo thể loại bằng AJAX
        public IActionResult LocSach(int maTl)
        {
            var theLoai = _context.TheLoais
                .FirstOrDefault(t => t.MaTl == maTl);

            var dsSach = _context.Saches
                .Where(s => s.MaTl == maTl && s.Gia >= 100)
                .ToList();

            ViewBag.TenTheLoai = theLoai?.TenTl ?? "Danh sách sách";

            return PartialView("NguyenThePhuc_DanhSachSach", dsSach);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}
