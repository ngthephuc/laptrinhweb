
// BookHub - hiệu ứng giao diện cơ bản
$(function () {

    console.log("main.js đã được tải!");

    // Nút lên đầu trang
    $(window).on('scroll', function () {
        $('.to-top').toggle($(this).scrollTop() > 200);
    });

    $('.to-top').on('click', function () {
        $('html, body').animate({ scrollTop: 0 }, 400);
    });

    // Chọn nội dung ô tìm kiếm
    $('.search-box input').on('focus', function () {
        $(this).select();
    });

    // AJAX lọc sách theo thể loại
    $(document).on('click', '.menu-theloai', function (e) {
        e.preventDefault();

        var maTl = $(this).attr('data-id');
        var menuDuocChon = $(this);

        console.log("Đã bấm thể loại, mã:", maTl);

        $.ajax({
            url: '/Home/LocSach',
            type: 'GET',
            data: { maTl: maTl },

            success: function (result) {
                console.log("AJAX thành công!");

                $('#vung-sach').html(result);

                $('.menu li').removeClass('active');
                menuDuocChon.parent().addClass('active');
            },

            error: function (xhr) {
                console.log("AJAX lỗi:", xhr.status);
                console.log(xhr.responseText);
                alert("Lỗi tải sách! Mã lỗi: " + xhr.status);
            }
        });
    });

});
