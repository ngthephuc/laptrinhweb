using Microsoft.EntityFrameworkCore;
using MyWebApp.Data; // Đảm bảo khai báo namespace chứa SchoolContext và DbInitializer
using MyWebApp.Models;

namespace MyWebApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Đăng ký SchoolContext là một DbContext của ứng dụng kết nối tới SQL Server
            builder.Services.AddDbContext<SchoolContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("SchoolContext")));

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            var app = builder.Build();

            // Khởi tạo cơ sở dữ liệu và nạp dữ liệu mẫu (Seeding Data)
            using (var scope = app.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                DbInitializer.Initialize(services);
            }

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseRouting();

            app.UseAuthorization();

            app.MapStaticAssets();
            app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Learners}/{action=Index}/{id?}")
    .WithStaticAssets();
            app.Run();
        }
    }
}