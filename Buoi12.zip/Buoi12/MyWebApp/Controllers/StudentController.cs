﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MyWebApp.Models;

namespace MyWebApp.Controllers
{
    public class StudentController : Controller
    {
        private static List<Student> listStudents = new List<Student>()
        {
            new Student() { Id = 101, Name = "Hải Nam", Branch = Branch.IT, Gender = Gender.Male, IsRegular=true, Address = "A1-2018", Email = "nam@g.com" },
            new Student() { Id = 102, Name = "Minh Tú", Branch = Branch.BE, Gender = Gender.Female, IsRegular=true, Address = "A1-2019", Email = "tu@g.com" },
            new Student() { Id = 103, Name = "Hoàng Phong", Branch = Branch.CE, Gender = Gender.Male, IsRegular=false, Address = "A1-2020", Email = "phong@g.com" },
            new Student() { Id = 104, Name = "Xuân Mai", Branch = Branch.EE, Gender = Gender.Female, IsRegular = false, Address = "A1-2021", Email = "mai@g.com" }
        };

        [Route("Admin/Student/List")]
        public IActionResult Index() => View(listStudents);

        [HttpGet, Route("Admin/Student/Add")]
        public IActionResult Create()
        {
            SetupViewBags();
            return View();
        }

        [HttpPost, Route("Admin/Student/Add")]
        public IActionResult Create(Student s)
        {
            if (ModelState.IsValid)
            {
                s.Id = listStudents.Any() ? listStudents.Max(x => x.Id) + 1 : 101;
                listStudents.Add(s);
                return RedirectToAction("Index");
            }
            SetupViewBags();
            return View(s);
        }

        [HttpGet, Route("Admin/Student/Edit/{id}")]
        public IActionResult Edit(int id)
        {
            var student = listStudents.FirstOrDefault(s => s.Id == id);
            if (student == null) return NotFound();
            SetupViewBags();
            return View(student);
        }

        [HttpPost, Route("Admin/Student/Edit/{id}")]
        public IActionResult Edit(int id, Student s)
        {
            if (ModelState.IsValid)
            {
                var student = listStudents.FirstOrDefault(x => x.Id == id);
                if (student != null)
                {
                    student.Name = s.Name; student.Branch = s.Branch; student.Gender = s.Gender;
                    student.IsRegular = s.IsRegular; student.Address = s.Address; student.Email = s.Email; student.DateOfBorth = s.DateOfBorth;
                }
                return RedirectToAction("Index");
            }
            SetupViewBags();
            return View(s);
        }

        [HttpGet, Route("Admin/Student/Delete/{id}")]
        public IActionResult Delete(int id)
        {
            var student = listStudents.FirstOrDefault(s => s.Id == id);
            if (student == null) return NotFound();
            return View(student);
        }

        [HttpPost, ActionName("Delete"), Route("Admin/Student/Delete/{id}")]
        public IActionResult DeleteConfirmed(int id)
        {
            var student = listStudents.FirstOrDefault(s => s.Id == id);
            if (student != null) listStudents.Remove(student);
            return RedirectToAction("Index");
        }

        private void SetupViewBags()
        {
            ViewBag.AllGenders = Enum.GetValues(typeof(Gender)).Cast<Gender>().ToList();
            ViewBag.AllBranches = new List<SelectListItem> {
                new SelectListItem { Text = "IT", Value = "0" },
                new SelectListItem { Text = "BE", Value = "1" },
                new SelectListItem { Text = "CE", Value = "2" },
                new SelectListItem { Text = "EE", Value = "3" }
            };
        }
    }
}