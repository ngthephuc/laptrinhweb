﻿using System;
using System.Collections.Generic;

namespace NguyenThePhuc_241230818.Models;

public partial class TblAccount
{
    public int Uid { get; set; }

    public string? Username { get; set; }

    public string? Password { get; set; }
}
