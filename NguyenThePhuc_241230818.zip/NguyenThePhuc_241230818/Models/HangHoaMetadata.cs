﻿
using System.ComponentModel.DataAnnotations;

namespace NguyenThePhuc_241230818.Models
{
    public class HangHoaMetadata
    {
        [Required(ErrorMessage = "Vui lòng nhập tên hàng")]
        public string TenHang { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập giá")]
        [Range(100, 5000, ErrorMessage = "Giá phải từ 100 đến 5000")]
        public decimal? Gia { get; set; }

        [RegularExpression(@".*\.(jpg|png|gif|tiff)$",
            ErrorMessage = "Ảnh phải có đuôi jpg, png, gif hoặc tiff")]
        public string Anh { get; set; }
    }
}
