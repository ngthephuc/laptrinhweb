
using Microsoft.AspNetCore.Mvc;
using NguyenThePhuc_241230818.Models;
using System.Diagnostics;
using System.Linq;
namespace NguyenThePhuc_241230818.Controllers
{
    public class HomeController : Controller
    {
        private readonly QLHangHoaContext _db;

        public HomeController(QLHangHoaContext db)
        {
            _db = db;
        }


        public IActionResult Index()
        {
            ViewBag.LoaiHangs = _db.LoaiHangs.ToList();

            var dsHangHoa = _db.HangHoas
                               .Where(h => h.Gia >= 100)
                               .ToList();

            return View(dsHangHoa);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
        public IActionResult LocHangHoa(int maLoai)
        {
            var dsHangHoa = _db.HangHoas
                .Where(h => h.MaLoai == maLoai && h.Gia >= 100)
                .ToList();

            return PartialView("_DanhSachHangHoa", dsHangHoa);
        }
        // Hiển thị form thêm hàng hóa
        [HttpGet]
        public IActionResult ThemHangHoa()
        {
            ViewBag.LoaiHangs = _db.LoaiHangs.ToList();
            return View();
        }

        // Xử lý thêm hàng hóa
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ThemHangHoa(HangHoa hang)
        {
            if (ModelState.IsValid)
            {
                _db.HangHoas.Add(hang);
                _db.SaveChanges();

                return RedirectToAction("Index");
            }

            ViewBag.LoaiHangs = _db.LoaiHangs.ToList();
            return View(hang);
        }
    }
}
